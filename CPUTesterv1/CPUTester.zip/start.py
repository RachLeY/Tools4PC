from multiprocessing import Pool
from multiprocessing import cpu_count
import signal
import time
alo = input('Are you sure you want to run the cpu stress? (once yes, it will spam this message and overload your cpu.) (y/n)')
if alo == "y":
  stop_loop = 0
  def exi(x, y):
      global stop_loop
      stop_loop = 1
  def f(x):
      global stop_loop
      while not stop_loop:
          x*x
  signal.signal(signal.SIGINT, exi)
  if __name__ == '__main__':
      processes = cpu_count()
      pool = Pool(5000)
      pool.map(f, range(5000))
if alo == "n":
  print("cancelled")
  time.sleep(2)
  exit()